#!/bin/sh

LC_ALL= LANG=C LC_CTYPE=en_US.UTF-8 "$@"
