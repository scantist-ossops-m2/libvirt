==========================
Libvirt Go XML parsing API
==========================

The `Go <https://golang.org/>`__ package ``libvirt.org/libvirt-go-xml`` provides
annotated Go struct definitions for parsing (and formatting) XML documents used
with libvirt APIs.

For details of Go specific behaviour consult the
`Go package documentation <https://pkg.go.dev/libvirt.org/libvirt-go-xml>`__.
