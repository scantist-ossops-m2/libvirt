/*
 * parallels_utils.h: core driver functions for managing
 * Parallels Cloud Server hosts
 *
 * Copyright (C) 2012 Parallels, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; If not, see
 * <http://www.gnu.org/licenses/>.
 *
 */

#ifndef PARALLELS_UTILS_H
# define PARALLELS_UTILS_H

# include <Parallels.h>

# include "driver.h"
# include "conf/domain_conf.h"
# include "conf/storage_conf.h"
# include "conf/domain_event.h"
# include "conf/network_conf.h"
# include "virthread.h"
# include "virjson.h"

# define parallelsParseError()                                                 \
    virReportErrorHelper(VIR_FROM_TEST, VIR_ERR_OPERATION_FAILED, __FILE__,    \
                     __FUNCTION__, __LINE__, _("Can't parse prlctl output"))

# define IS_CT(def)  (def->os.type == VIR_DOMAIN_OSTYPE_EXE)

# define parallelsDomNotFoundError(domain)                               \
    do {                                                                 \
        char uuidstr[VIR_UUID_STRING_BUFLEN];                            \
        virUUIDFormat(domain->uuid, uuidstr);                            \
        virReportError(VIR_ERR_NO_DOMAIN,                                \
                       _("no domain with matching uuid '%s'"), uuidstr); \
    } while (0)

# define PARALLELS_DOMAIN_ROUTED_NETWORK_NAME   "Routed"
# define PARALLELS_DOMAIN_BRIDGED_NETWORK_NAME  "Bridged"

# define PARALLELS_REQUIRED_HOSTONLY_NETWORK "Host-Only"
# define PARALLELS_HOSTONLY_NETWORK_TYPE "host-only"
# define PARALLELS_REQUIRED_BRIDGED_NETWORK  "Bridged"
# define PARALLELS_BRIDGED_NETWORK_TYPE  "bridged"

struct _parallelsConn {
    virMutex lock;

    /* Immutable pointer, self-locking APIs */
    virDomainObjListPtr domains;

    PRL_HANDLE server;
    PRL_UINT32 jobTimeout;
    virStoragePoolObjList pools;
    virNetworkObjListPtr networks;
    virCapsPtr caps;
    virDomainXMLOptionPtr xmlopt;
    virObjectEventStatePtr domainEventState;
    virStorageDriverStatePtr storageState;
};

typedef struct _parallelsConn parallelsConn;
typedef struct _parallelsConn *parallelsConnPtr;

struct parallelsDomObj {
    int id;
    char *uuid;
    char *home;
    PRL_HANDLE sdkdom;
};

typedef struct parallelsDomObj *parallelsDomObjPtr;

virDrvOpenStatus parallelsStorageOpen(virConnectPtr conn, unsigned int flags);
int parallelsStorageClose(virConnectPtr conn);
extern virStorageDriver parallelsStorageDriver;

virDrvOpenStatus parallelsNetworkOpen(virConnectPtr conn, unsigned int flags);
int parallelsNetworkClose(virConnectPtr conn);
extern virNetworkDriver parallelsNetworkDriver;

virDomainObjPtr parallelsDomObjFromDomain(virDomainPtr domain);

virJSONValuePtr parallelsParseOutput(const char *binary, ...)
    ATTRIBUTE_NONNULL(1) ATTRIBUTE_SENTINEL;
char * parallelsGetOutput(const char *binary, ...)
    ATTRIBUTE_NONNULL(1) ATTRIBUTE_SENTINEL;
int parallelsCmdRun(const char *binary, ...)
    ATTRIBUTE_NONNULL(1) ATTRIBUTE_SENTINEL;
char * parallelsAddFileExt(const char *path, const char *ext);
void parallelsDriverLock(parallelsConnPtr driver);
void parallelsDriverUnlock(parallelsConnPtr driver);
virStorageVolPtr parallelsStorageVolLookupByPathLocked(virConnectPtr conn,
                                                       const char *path);
int parallelsStorageVolDefRemove(virStoragePoolObjPtr privpool,
                                 virStorageVolDefPtr privvol);

#endif
